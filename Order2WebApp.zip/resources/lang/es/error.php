<?php 

return [
    'back' => 'back',
    'back_to_home' => 'back_to_home',
    'page' => [
        'not_found' => 'page.not_found',
    ],
    'permission' => 'User does not have the permission',
    'store_disabled' => 'store_disabled',
];